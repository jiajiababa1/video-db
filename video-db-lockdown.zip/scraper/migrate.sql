-- 数据库迁移: 非破坏性修复
-- 只在 Supabase SQL Editor 中执行一次
-- 不会删除任何数据, 只添加字段和函数

-- ═══════════════════════════════════════════
-- 1. 添加新字段 (如果不存在)
-- ═══════════════════════════════════════════
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS monsnode_video_id TEXT DEFAULT '';
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS has_mp4 BOOLEAN DEFAULT false;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS needs_rescrape BOOLEAN DEFAULT false;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS mp4_checked_at TIMESTAMPTZ;

-- ═══════════════════════════════════════════
-- 2. 更新现有数据
-- ═══════════════════════════════════════════
UPDATE public.videos SET has_mp4 = true WHERE duration LIKE '%video.twimg.com%';
UPDATE public.videos SET needs_rescrape = true WHERE duration NOT LIKE '%video.twimg.com%' OR duration IS NULL OR duration = '';

-- ═══════════════════════════════════════════
-- 3. 索引
-- ═══════════════════════════════════════════
CREATE INDEX IF NOT EXISTS idx_videos_has_mp4 ON public.videos(has_mp4);
CREATE INDEX IF NOT EXISTS idx_videos_needs_rescrape ON public.videos(needs_rescrape);

-- ═══════════════════════════════════════════
-- 4. 核心: UPSERT 函数 (INSERT ON CONFLICT)
--    解决 merge-duplicates 只认主键 id 的问题
--    这个函数用 video_id 的 UNIQUE 约束做冲突检测
-- ═══════════════════════════════════════════
DROP FUNCTION IF EXISTS public.upsert_videos(jsonb);
CREATE OR REPLACE FUNCTION public.upsert_videos(videos jsonb) RETURNS void AS $$
DECLARE
  v jsonb;
BEGIN
  FOR v IN SELECT * FROM jsonb_array_elements(videos)
  LOOP
    INSERT INTO public.videos (
      video_id, title, thumbnail_url, video_url, author,
      duration, views, monsnode_video_id,
      source_page, source_section,
      vote_up, vote_down,
      scraped_at, updated_at,
      has_mp4, needs_rescrape, mp4_checked_at
    ) VALUES (
      v->>'video_id',
      v->>'title',
      v->>'thumbnail_url',
      v->>'video_url',
      v->>'author',
      v->>'duration',
      v->>'views',
      v->>'monsnode_video_id',
      v->>'source_page',
      v->>'source_section',
      COALESCE((v->>'vote_up')::integer, 0),
      COALESCE((v->>'vote_down')::integer, 0),
      COALESCE((v->>'scraped_at')::timestamptz, NOW()),
      NOW(),
      COALESCE((v->>'has_mp4')::boolean, false),
      COALESCE((v->>'needs_rescrape')::boolean, true),
      COALESCE((v->>'mp4_checked_at')::timestamptz, NOW())
    )
    ON CONFLICT (video_id) DO UPDATE SET
      title = COALESCE(NULLIF(v->>'title', ''), videos.title),
      thumbnail_url = COALESCE(NULLIF(v->>'thumbnail_url', ''), videos.thumbnail_url),
      video_url = COALESCE(NULLIF(v->>'video_url', ''), videos.video_url),
      author = COALESCE(NULLIF(v->>'author', ''), videos.author),
      duration = COALESCE(NULLIF(v->>'duration', ''), videos.duration),
      views = COALESCE(NULLIF(v->>'views', ''), videos.views),
      monsnode_video_id = COALESCE(NULLIF(v->>'monsnode_video_id', ''), videos.monsnode_video_id),
      vote_up = COALESCE((v->>'vote_up')::integer, videos.vote_up),
      vote_down = COALESCE((v->>'vote_down')::integer, videos.vote_down),
      source_page = COALESCE(NULLIF(v->>'source_page', ''), videos.source_page),
      -- 拼接 source_section: 新栏目追加到已有栏目后面 (用 | 分隔, 自动去重)
      source_section = CASE
          WHEN COALESCE(videos.source_section, '') = '' THEN COALESCE(NULLIF(v->>'source_section', ''), '')
          WHEN COALESCE(NULLIF(v->>'source_section', ''), '') = '' THEN videos.source_section
          WHEN videos.source_section = (v->>'source_section') THEN videos.source_section
          WHEN videos.source_section ILIKE (v->>'source_section') || '|%' THEN videos.source_section
          WHEN videos.source_section ILIKE '%|' || (v->>'source_section') THEN videos.source_section
          WHEN videos.source_section ILIKE '%|' || (v->>'source_section') || '|%' THEN videos.source_section
          ELSE videos.source_section || '|' || COALESCE(v->>'source_section', '')
      END,
      scraped_at = COALESCE((v->>'scraped_at')::timestamptz, videos.scraped_at),
      updated_at = NOW(),
      has_mp4 = COALESCE((v->>'has_mp4')::boolean, videos.has_mp4),
      needs_rescrape = COALESCE((v->>'needs_rescrape')::boolean, videos.needs_rescrape),
      mp4_checked_at = COALESCE((v->>'mp4_checked_at')::timestamptz, videos.mp4_checked_at);
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 授权
GRANT EXECUTE ON FUNCTION public.upsert_videos(jsonb) TO anon;
GRANT EXECUTE ON FUNCTION public.upsert_videos(jsonb) TO service_role;

-- ═══════════════════════════════════════════
-- 5. 重试计数器
-- ═══════════════════════════════════════════
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS vote_up INTEGER DEFAULT 0;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS vote_down INTEGER DEFAULT 0;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS removed BOOLEAN DEFAULT false;
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS mp4_url TEXT DEFAULT '';

-- 回填: 从 duration 字段迁移 MP4 URL 到 mp4_url
UPDATE public.videos SET mp4_url = duration WHERE duration LIKE '%video.twimg.com%' AND (mp4_url IS NULL OR mp4_url = '');

-- ═══════════════════════════════════════════
-- VIP 会员系统
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.user_vips (
    id            SERIAL PRIMARY KEY,
    device_id     TEXT UNIQUE NOT NULL,
    vip_level     TEXT NOT NULL DEFAULT 'free',  -- free | vip | vvip | svip | ultimate
    is_admin      BOOLEAN DEFAULT false,
    activated_at  TIMESTAMPTZ DEFAULT NOW(),
    expires_at    TIMESTAMPTZ,                   -- NULL = 永久
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.activation_codes (
    id            SERIAL PRIMARY KEY,
    code          TEXT UNIQUE NOT NULL,
    vip_level     TEXT NOT NULL,                 -- vip | vvip | svip
    max_uses      INTEGER DEFAULT 1,             -- 可用次数, 0=无限
    used_count    INTEGER DEFAULT 0,
    created_by    TEXT DEFAULT '',               -- 谁创建的
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    expires_at    TIMESTAMPTZ                    -- NULL = 永久有效
);

-- RLS (先删后建, 避免重复执行报错)
ALTER TABLE public.user_vips ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activation_codes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon 可读取自己的 VIP" ON public.user_vips;
DROP POLICY IF EXISTS "anon 可注册 VIP" ON public.user_vips;
DROP POLICY IF EXISTS "anon 可更新自己的 VIP" ON public.user_vips;
DROP POLICY IF EXISTS "anon 可读取激活码" ON public.activation_codes;
DROP POLICY IF EXISTS "anon 可消耗激活码" ON public.activation_codes;
DROP POLICY IF EXISTS "管理员可创建激活码" ON public.activation_codes;

CREATE POLICY "anon 可读取自己的 VIP" ON public.user_vips FOR SELECT TO anon USING (true);
CREATE POLICY "anon 可注册 VIP" ON public.user_vips FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "anon 可更新自己的 VIP" ON public.user_vips FOR UPDATE TO anon USING (true) WITH CHECK (true);

CREATE POLICY "anon 可读取激活码" ON public.activation_codes FOR SELECT TO anon USING (true);
CREATE POLICY "anon 可消耗激活码" ON public.activation_codes FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "管理员可创建激活码" ON public.activation_codes FOR INSERT TO anon WITH CHECK (true);

-- 索引
CREATE INDEX IF NOT EXISTS idx_user_vips_device ON public.user_vips(device_id);
CREATE INDEX IF NOT EXISTS idx_user_vips_level ON public.user_vips(vip_level);
CREATE INDEX IF NOT EXISTS idx_activation_codes_code ON public.activation_codes(code);

-- 默认激活码 (一次性使用, 用户自行修改)
INSERT INTO public.activation_codes (code, vip_level, max_uses)
VALUES ('VIP2026', 'vip', 100),
       ('VVIP2026', 'vvip', 50),
       ('SVIP2026', 'svip', 20)
ON CONFLICT (code) DO NOTHING;

-- RPC: 兑换激活码
DROP FUNCTION IF EXISTS public.redeem_code(TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.redeem_code(p_device_id TEXT, p_code TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT, vip_level TEXT) AS $$
DECLARE
    v_code RECORD;
    v_existing RECORD;
BEGIN
    -- 查找激活码
    SELECT * INTO v_code FROM public.activation_codes
    WHERE code = p_code
      AND (expires_at IS NULL OR expires_at > NOW())
      AND (max_uses = 0 OR used_count < max_uses);

    IF v_code IS NULL THEN
        RETURN QUERY SELECT false, '激活码无效或已用完', ''::TEXT;
        RETURN;
    END IF;

    -- 检查用户是否已有更高等级
    SELECT * INTO v_existing FROM public.user_vips WHERE device_id = p_device_id;
    IF FOUND THEN
        IF v_existing.vip_level = 'ultimate' THEN
            RETURN QUERY SELECT false, '已是终极VIP, 无需升级', v_existing.vip_level;
            RETURN;
        END IF;
        -- 不允许降级
        IF v_existing.vip_level = 'svip' AND v_code.vip_level IN ('vip', 'vvip') THEN
            RETURN QUERY SELECT false, '当前 SVIP 等级更高, 无需降级', v_existing.vip_level;
            RETURN;
        END IF;
        IF v_existing.vip_level = 'vvip' AND v_code.vip_level = 'vip' THEN
            RETURN QUERY SELECT false, '当前 VVIP 等级更高, 无需降级', v_existing.vip_level;
            RETURN;
        END IF;
    END IF;

    -- 消耗激活码
    UPDATE public.activation_codes SET used_count = used_count + 1 WHERE id = v_code.id;

    -- 更新或插入用户VIP
    INSERT INTO public.user_vips (device_id, vip_level, activated_at)
    VALUES (p_device_id, v_code.vip_level, NOW())
    ON CONFLICT (device_id) DO UPDATE SET
        vip_level = EXCLUDED.vip_level,
        activated_at = NOW(),
        expires_at = NULL;

    RETURN QUERY SELECT true, '升级成功! ' || v_code.vip_level, v_code.vip_level;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.redeem_code(TEXT, TEXT) TO anon;

-- ═══════════════════════════════════════════
-- 云端收藏 (VVIP+ 专享, 跨设备同步)
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.cloud_favorites (
    id          SERIAL PRIMARY KEY,
    device_id   TEXT NOT NULL,
    video_id    TEXT NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(device_id, video_id)
);
CREATE INDEX IF NOT EXISTS idx_cf_device ON public.cloud_favorites(device_id);
ALTER TABLE public.cloud_favorites ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理自己的云收藏" ON public.cloud_favorites;
CREATE POLICY "anon 管理自己的云收藏" ON public.cloud_favorites FOR ALL TO anon USING (true) WITH CHECK (true);

-- RPC: 同步云端收藏 (VVIP+)
DROP FUNCTION IF EXISTS public.sync_favorites(TEXT, TEXT[]);
CREATE OR REPLACE FUNCTION public.sync_favorites(p_device_id TEXT, p_video_ids TEXT[]) RETURNS void AS $$
BEGIN
  -- 删除不在列表中的
  DELETE FROM public.cloud_favorites WHERE device_id = p_device_id AND video_id != ALL(p_video_ids);
  -- 插入新的 (幂等)
  IF p_video_ids IS NOT NULL AND array_length(p_video_ids, 1) > 0 THEN
    INSERT INTO public.cloud_favorites (device_id, video_id)
    SELECT p_device_id, unnest(p_video_ids)
    ON CONFLICT (device_id, video_id) DO NOTHING;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.sync_favorites(TEXT, TEXT[]) TO anon;

-- RPC: 下载云端收藏 (VVIP+)
DROP FUNCTION IF EXISTS public.load_favorites(TEXT);
CREATE OR REPLACE FUNCTION public.load_favorites(p_device_id TEXT)
RETURNS TABLE(video_id TEXT) AS $$
BEGIN
  RETURN QUERY SELECT cf.video_id FROM public.cloud_favorites cf WHERE cf.device_id = p_device_id ORDER BY cf.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.load_favorites(TEXT) TO anon;

-- ═══════════════════════════════════════════
-- VIP 先行看 (新视频免费用户延迟24h看到)
-- ═══════════════════════════════════════════
ALTER TABLE public.videos ADD COLUMN IF NOT EXISTS vip_early BOOLEAN DEFAULT false;

-- RPC: 管理员设置终极VIP (仅限管理员调用, code='ADMIN_MASTER_KEY' 校验)
DROP FUNCTION IF EXISTS public.admin_activate(TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.admin_activate(p_device_id TEXT, p_master_key TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
BEGIN
    -- 主密钥 (纯文本, 用户自行修改为自己独有的密码)
    -- 默认: 'admin2026ultimate' (部署后立即改掉!)
    IF p_master_key != 'admin2026ultimate' THEN
        RETURN QUERY SELECT false, '管理员密钥错误';
        RETURN;
    END IF;

    INSERT INTO public.user_vips (device_id, vip_level, is_admin, activated_at)
    VALUES (p_device_id, 'ultimate', true, NOW())
    ON CONFLICT (device_id) DO UPDATE SET
        vip_level = 'ultimate',
        is_admin = true,
        activated_at = NOW();

    RETURN QUERY SELECT true, '终极VIP管理员已激活';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.admin_activate(TEXT, TEXT) TO anon;

-- 安全递增 retry_count (RPC, 避免 PATCH 覆盖)
DROP FUNCTION IF EXISTS public.increment_retry(TEXT);
CREATE OR REPLACE FUNCTION public.increment_retry(vid TEXT) RETURNS void AS $$
BEGIN
  UPDATE public.videos
  SET retry_count = COALESCE(retry_count, 0) + 1,
      updated_at = NOW()
  WHERE video_id = vid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.increment_retry(TEXT) TO anon;

-- ═══════════════════════════════════════════
-- 6. 批量标记重爬函数
-- ═══════════════════════════════════════════
DROP FUNCTION IF EXISTS public.mark_rescrape(TEXT[]);
CREATE OR REPLACE FUNCTION public.mark_rescrape(video_ids TEXT[]) RETURNS void AS $$
BEGIN
  UPDATE public.videos SET needs_rescrape = true, updated_at = NOW()
  WHERE video_id = ANY(video_ids);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.mark_rescrape(TEXT[]) TO anon;

-- ═══════════════════════════════════════════
-- RPC: 热门作者聚合
-- ═══════════════════════════════════════════
DROP FUNCTION IF EXISTS public.popular_authors();
CREATE OR REPLACE FUNCTION public.popular_authors() RETURNS TABLE(author TEXT, video_count BIGINT, total_views BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT v.author, COUNT(*)::BIGINT, COALESCE(SUM(NULLIF(v.views, '')::BIGINT), 0)
  FROM public.videos v
  WHERE v.author IS NOT NULL AND v.author != ''
  GROUP BY v.author
  ORDER BY COUNT(*) DESC
  LIMIT 50;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

GRANT EXECUTE ON FUNCTION public.popular_authors() TO anon;

-- ═══════════════════════════════════════════
-- 7. 修复 upsert: has_mp4 只增不减
--    (防止客户端/服务端爬虫互相覆盖)
-- ═══════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.upsert_videos(videos jsonb) RETURNS void AS $$
DECLARE
  v jsonb;
BEGIN
  FOR v IN SELECT * FROM jsonb_array_elements(videos)
  LOOP
    INSERT INTO public.videos (
      video_id, title, thumbnail_url, video_url, author,
      duration, views, monsnode_video_id,
      source_page, source_section,
      vote_up, vote_down,
      scraped_at, updated_at,
      has_mp4, needs_rescrape, mp4_checked_at
    ) VALUES (
      v->>'video_id',
      v->>'title',
      v->>'thumbnail_url',
      v->>'video_url',
      v->>'author',
      v->>'duration',
      v->>'views',
      v->>'monsnode_video_id',
      v->>'source_page',
      v->>'source_section',
      COALESCE((v->>'vote_up')::integer, 0),
      COALESCE((v->>'vote_down')::integer, 0),
      COALESCE((v->>'scraped_at')::timestamptz, NOW()),
      NOW(),
      COALESCE((v->>'has_mp4')::boolean, false),
      COALESCE((v->>'needs_rescrape')::boolean, true),
      COALESCE((v->>'mp4_checked_at')::timestamptz, NOW())
    )
    ON CONFLICT (video_id) DO UPDATE SET
      title = COALESCE(NULLIF(v->>'title', ''), videos.title),
      thumbnail_url = COALESCE(NULLIF(v->>'thumbnail_url', ''), videos.thumbnail_url),
      video_url = COALESCE(NULLIF(v->>'video_url', ''), videos.video_url),
      author = COALESCE(NULLIF(v->>'author', ''), videos.author),
      -- MP4 URL: 只在新值有效时覆盖 (不把空值写回)
      duration = CASE
          WHEN (v->>'has_mp4')::boolean AND NULLIF(v->>'duration', '') IS NOT NULL
          THEN v->>'duration'
          ELSE videos.duration
      END,
      views = COALESCE(NULLIF(v->>'views', ''), videos.views),
      monsnode_video_id = COALESCE(NULLIF(v->>'monsnode_video_id', ''), videos.monsnode_video_id),
      vote_up = COALESCE((v->>'vote_up')::integer, videos.vote_up),
      vote_down = COALESCE((v->>'vote_down')::integer, videos.vote_down),
      source_page = COALESCE(NULLIF(v->>'source_page', ''), videos.source_page),
      -- 拼接 source_section (去重)
      source_section = CASE
          WHEN COALESCE(videos.source_section, '') = '' THEN COALESCE(NULLIF(v->>'source_section', ''), '')
          WHEN COALESCE(NULLIF(v->>'source_section', ''), '') = '' THEN videos.source_section
          WHEN videos.source_section = (v->>'source_section') THEN videos.source_section
          WHEN videos.source_section ILIKE (v->>'source_section') || '|%' THEN videos.source_section
          WHEN videos.source_section ILIKE '%|' || (v->>'source_section') THEN videos.source_section
          WHEN videos.source_section ILIKE '%|' || (v->>'source_section') || '|%' THEN videos.source_section
          ELSE videos.source_section || '|' || COALESCE(v->>'source_section', '')
      END,
      scraped_at = COALESCE((v->>'scraped_at')::timestamptz, videos.scraped_at),
      updated_at = NOW(),
      -- has_mp4: 只在新值为 true 时覆盖, 否则保留旧值 (防止客户端/服务端冲突)
      has_mp4 = CASE WHEN (v->>'has_mp4')::boolean THEN true ELSE videos.has_mp4 END,
      -- mp4_url: 只在新值有效时覆盖
      mp4_url = CASE WHEN (v->>'has_mp4')::boolean AND NULLIF(v->>'duration', '') IS NOT NULL
          THEN v->>'duration' ELSE videos.mp4_url END,
      needs_rescrape = COALESCE((v->>'needs_rescrape')::boolean, videos.needs_rescrape),
      mp4_checked_at = COALESCE((v->>'mp4_checked_at')::timestamptz, videos.mp4_checked_at);
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ═══════════════════════════════════════════
-- 账号登录系统 (用户名+密码)
-- ═══════════════════════════════════════════
CREATE TABLE IF NOT EXISTS public.user_accounts (
    id            SERIAL PRIMARY KEY,
    username      TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    device_id     TEXT DEFAULT '',
    vip_level     TEXT NOT NULL DEFAULT 'free',
    is_admin      BOOLEAN DEFAULT false,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    last_login    TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.user_accounts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 可读写账号" ON public.user_accounts;
CREATE POLICY "anon 可读写账号" ON public.user_accounts FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE INDEX IF NOT EXISTS idx_accounts_username ON public.user_accounts(username);

-- ✅ 管理员账号: kuo / kuo2026  (终极VIP + 蓝V + 管理员, 不可降级/不可封禁)
INSERT INTO public.user_accounts (username, password_hash, vip_level, is_admin, verified, display_name)
VALUES ('kuo', 'a2ced91de6ae4ead293db6bf4d0a91ac92331c6ffe4c5a73fd30ddaa9537d302', 'ultimate', true, true, '站长')
ON CONFLICT (username) DO UPDATE SET is_admin = true, verified = true, vip_level = 'ultimate';

-- ═══ 安全约束: 管理员账号不可被修改 ═══
-- ban/unban/降级操作不生效于管理员
CREATE OR REPLACE FUNCTION public.admin_action(p_admin TEXT, p_action TEXT, p_target TEXT, p_detail TEXT DEFAULT '')
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
DECLARE v_admin RECORD; v_target RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username = p_admin AND is_admin = true AND banned = false;
  IF v_admin IS NULL THEN RETURN QUERY SELECT false, '无管理员权限'; RETURN; END IF;

  -- 不允许操作其他管理员
  SELECT * INTO v_target FROM public.user_accounts WHERE username = p_target;
  IF v_target IS NOT NULL AND v_target.is_admin = true AND p_action IN ('ban','unban','set_vip','unverify') THEN
    RETURN QUERY SELECT false, '不能操作管理员账号'; RETURN;
  END IF;

  INSERT INTO public.admin_log (admin_user, action, target, detail) VALUES (p_admin, p_action, p_target, p_detail);

  CASE p_action
    WHEN 'ban' THEN
      UPDATE public.user_accounts SET banned = true, ban_reason = p_detail WHERE username = p_target AND is_admin = false;
      INSERT INTO public.bans (username, reason, banned_by) VALUES (p_target, p_detail, p_admin);
      RETURN QUERY SELECT true, '已封禁 ' || p_target;
    WHEN 'unban' THEN
      UPDATE public.user_accounts SET banned = false, ban_reason = '' WHERE username = p_target;
      UPDATE public.bans SET unbanned_at = NOW() WHERE username = p_target AND unbanned_at IS NULL;
      RETURN QUERY SELECT true, '已解封 ' || p_target;
    WHEN 'verify' THEN
      UPDATE public.user_accounts SET verified = true WHERE username = p_target;
      RETURN QUERY SELECT true, '已认证 ' || p_target;
    WHEN 'unverify' THEN
      UPDATE public.user_accounts SET verified = false WHERE username = p_target AND is_admin = false;
      RETURN QUERY SELECT true, '已取消认证 ' || p_target;
    WHEN 'set_vip' THEN
      UPDATE public.user_accounts SET vip_level = p_detail WHERE username = p_target AND is_admin = false;
      RETURN QUERY SELECT true, '已设置 ' || p_target || ' → ' || p_detail;
    WHEN 'delete_video' THEN
      DELETE FROM public.videos WHERE video_id = p_target;
      RETURN QUERY SELECT true, '已删除视频 ' || p_target;
    ELSE
      RETURN QUERY SELECT false, '未知操作';
  END CASE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.admin_action(TEXT, TEXT, TEXT, TEXT) TO anon;

-- ═══ 登录强化: 检查封禁状态 ═══
DROP FUNCTION IF EXISTS public.login_account(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.login_account(p_username TEXT, p_password_hash TEXT, p_device_id TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT, vip_level TEXT, is_admin BOOLEAN) AS $$
DECLARE v_acc RECORD;
BEGIN
  SELECT * INTO v_acc FROM public.user_accounts WHERE username = p_username;
  IF v_acc IS NULL THEN RETURN QUERY SELECT false, '账号不存在', ''::TEXT, false; RETURN; END IF;
  IF v_acc.banned THEN RETURN QUERY SELECT false, '账号已被封禁', ''::TEXT, false; RETURN; END IF;
  IF v_acc.password_hash != p_password_hash THEN RETURN QUERY SELECT false, '密码错误', ''::TEXT, false; RETURN; END IF;
  UPDATE public.user_accounts SET device_id = p_device_id, last_login = NOW() WHERE id = v_acc.id;
  RETURN QUERY SELECT true, '登录成功', v_acc.vip_level, v_acc.is_admin;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.login_account(TEXT, TEXT, TEXT) TO anon;

-- RPC: 登录
DROP FUNCTION IF EXISTS public.login_account(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.login_account(p_username TEXT, p_password_hash TEXT, p_device_id TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT, vip_level TEXT, is_admin BOOLEAN) AS $$
DECLARE v_acc RECORD;
BEGIN
    SELECT * INTO v_acc FROM public.user_accounts WHERE username = p_username;
    IF v_acc IS NULL THEN RETURN QUERY SELECT false, '账号不存在', ''::TEXT, false; RETURN; END IF;
    IF v_acc.password_hash != p_password_hash THEN RETURN QUERY SELECT false, '密码错误', ''::TEXT, false; RETURN; END IF;
    UPDATE public.user_accounts SET device_id = p_device_id, last_login = NOW() WHERE id = v_acc.id;
    RETURN QUERY SELECT true, '登录成功', v_acc.vip_level, v_acc.is_admin;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.login_account(TEXT, TEXT, TEXT) TO anon;

-- RPC: 改密码
DROP FUNCTION IF EXISTS public.change_password(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.change_password(p_username TEXT, p_old_hash TEXT, p_new_hash TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
BEGIN
    UPDATE public.user_accounts SET password_hash = p_new_hash WHERE username = p_username AND password_hash = p_old_hash;
    IF FOUND THEN RETURN QUERY SELECT true, '密码修改成功';
    ELSE RETURN QUERY SELECT false, '原密码错误'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.change_password(TEXT, TEXT, TEXT) TO anon;

-- RPC: 管理员升级用户
DROP FUNCTION IF EXISTS public.admin_upgrade(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.admin_upgrade(p_admin_username TEXT, p_target_username TEXT, p_level TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
DECLARE v_admin RECORD;
BEGIN
    SELECT * INTO v_admin FROM public.user_accounts WHERE username = p_admin_username AND is_admin = true;
    IF v_admin IS NULL THEN RETURN QUERY SELECT false, '无管理员权限'; RETURN; END IF;
    UPDATE public.user_accounts SET vip_level = p_level WHERE username = p_target_username;
    IF FOUND THEN RETURN QUERY SELECT true, '已升级 ' || p_target_username || ' → ' || p_level;
    ELSE RETURN QUERY SELECT false, '用户不存在'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.admin_upgrade(TEXT, TEXT, TEXT) TO anon;

-- ═══════════════════════════════════════════
-- ⚡ 创建你的唯一管理员账号 (只需执行一次!)
-- ═══════════════════════════════════════════
-- 1. 选好你的用户名和密码, 比如: 用户名=kuo 密码=MyP@ss2026
-- 2. 打开浏览器控制台(F12), 计算密码hash:
--    sha256('kuo:MyP@ss2026').then(h => console.log(h))
-- 3. 复制输出的hash, 替换下面的 '在此粘贴hash'
-- 4. 执行这条SQL:

-- INSERT INTO public.user_accounts (username, password_hash, vip_level, is_admin)
-- VALUES ('kuo', '在此粘贴hash', 'ultimate', true);

-- 5. 刷新网站, 用你的用户名和密码登录
-- ═══════════════════════════════════════════

-- ═══════════════════════════════════════════
-- 社交平台 + 管理面板
-- ═══════════════════════════════════════════

-- 用户档案扩展
ALTER TABLE public.user_accounts ADD COLUMN IF NOT EXISTS display_name TEXT DEFAULT '';
ALTER TABLE public.user_accounts ADD COLUMN IF NOT EXISTS bio TEXT DEFAULT '';
ALTER TABLE public.user_accounts ADD COLUMN IF NOT EXISTS verified BOOLEAN DEFAULT false;
ALTER TABLE public.user_accounts ADD COLUMN IF NOT EXISTS banned BOOLEAN DEFAULT false;
ALTER TABLE public.user_accounts ADD COLUMN IF NOT EXISTS ban_reason TEXT DEFAULT '';

-- 关注系统
CREATE TABLE IF NOT EXISTS public.user_follows (
    follower  TEXT NOT NULL,
    following TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (follower, following)
);
ALTER TABLE public.user_follows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理关注" ON public.user_follows;
CREATE POLICY "anon 管理关注" ON public.user_follows FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON public.user_follows(follower);
CREATE INDEX IF NOT EXISTS idx_follows_following ON public.user_follows(following);

-- 公告系统
CREATE TABLE IF NOT EXISTS public.announcements (
    id          SERIAL PRIMARY KEY,
    title       TEXT NOT NULL,
    content     TEXT NOT NULL,
    created_by  TEXT NOT NULL,
    is_active   BOOLEAN DEFAULT true,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 读取公告" ON public.announcements;
DROP POLICY IF EXISTS "anon 管理公告" ON public.announcements;
CREATE POLICY "anon 读取公告" ON public.announcements FOR SELECT TO anon USING (true);
CREATE POLICY "anon 管理公告" ON public.announcements FOR ALL TO anon USING (true) WITH CHECK (true);

-- 操作日志
CREATE TABLE IF NOT EXISTS public.admin_log (
    id          SERIAL PRIMARY KEY,
    admin_user  TEXT NOT NULL,
    action      TEXT NOT NULL,
    target      TEXT DEFAULT '',
    detail      TEXT DEFAULT '',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.admin_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理日志" ON public.admin_log;
CREATE POLICY "anon 管理日志" ON public.admin_log FOR ALL TO anon USING (true) WITH CHECK (true);

-- 封禁记录
CREATE TABLE IF NOT EXISTS public.bans (
    id          SERIAL PRIMARY KEY,
    username    TEXT NOT NULL,
    reason      TEXT DEFAULT '',
    banned_by   TEXT NOT NULL,
    banned_at   TIMESTAMPTZ DEFAULT NOW(),
    unbanned_at TIMESTAMPTZ
);
ALTER TABLE public.bans ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理封禁" ON public.bans;
CREATE POLICY "anon 管理封禁" ON public.bans FOR ALL TO anon USING (true) WITH CHECK (true);

-- ═══ RPC 函数 ═══

-- 查询用户档案
DROP FUNCTION IF EXISTS public.get_user_profile(TEXT);
CREATE OR REPLACE FUNCTION public.get_user_profile(p_username TEXT)
RETURNS TABLE(username TEXT, display_name TEXT, bio TEXT, verified BOOLEAN,
              vip_level TEXT, created_at TIMESTAMPTZ, follower_count BIGINT, following_count BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT a.username, a.display_name, a.bio, a.verified, a.vip_level, a.created_at,
    (SELECT COUNT(*) FROM public.user_follows WHERE following = p_username),
    (SELECT COUNT(*) FROM public.user_follows WHERE follower = p_username)
  FROM public.user_accounts a WHERE a.username = p_username AND a.banned = false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.get_user_profile(TEXT) TO anon;

-- 用户列表 (管理员)
DROP FUNCTION IF EXISTS public.list_users(TEXT, INTEGER, INTEGER);
CREATE OR REPLACE FUNCTION public.list_users(p_admin TEXT, p_offset INTEGER DEFAULT 0, p_limit INTEGER DEFAULT 50)
RETURNS TABLE(username TEXT, vip_level TEXT, verified BOOLEAN, banned BOOLEAN,
              created_at TIMESTAMPTZ, last_login TIMESTAMPTZ) AS $$
DECLARE v_admin RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username = p_admin AND is_admin = true;
  IF v_admin IS NULL THEN RETURN; END IF;
  RETURN QUERY SELECT a.username, a.vip_level, a.verified, a.banned, a.created_at, a.last_login
  FROM public.user_accounts a ORDER BY a.created_at DESC OFFSET p_offset LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.list_users(TEXT, INTEGER, INTEGER) TO anon;

-- 管理员操作封装
DROP FUNCTION IF EXISTS public.admin_action(TEXT, TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.admin_action(p_admin TEXT, p_action TEXT, p_target TEXT, p_detail TEXT DEFAULT '')
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
DECLARE v_admin RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username = p_admin AND is_admin = true AND banned = false;
  IF v_admin IS NULL THEN RETURN QUERY SELECT false, '无管理员权限'; RETURN; END IF;

  -- 记录日志
  INSERT INTO public.admin_log (admin_user, action, target, detail) VALUES (p_admin, p_action, p_target, p_detail);

  -- 执行操作
  CASE p_action
    WHEN 'ban' THEN
      UPDATE public.user_accounts SET banned = true, ban_reason = p_detail WHERE username = p_target AND is_admin = false;
      INSERT INTO public.bans (username, reason, banned_by) VALUES (p_target, p_detail, p_admin);
      RETURN QUERY SELECT true, '已封禁 ' || p_target;

    WHEN 'unban' THEN
      UPDATE public.user_accounts SET banned = false, ban_reason = '' WHERE username = p_target;
      UPDATE public.bans SET unbanned_at = NOW() WHERE username = p_target AND unbanned_at IS NULL;
      RETURN QUERY SELECT true, '已解封 ' || p_target;

    WHEN 'verify' THEN
      UPDATE public.user_accounts SET verified = true WHERE username = p_target;
      RETURN QUERY SELECT true, '已认证 ' || p_target;

    WHEN 'unverify' THEN
      UPDATE public.user_accounts SET verified = false WHERE username = p_target AND is_admin = false;
      RETURN QUERY SELECT true, '已取消认证 ' || p_target;

    WHEN 'set_vip' THEN
      UPDATE public.user_accounts SET vip_level = p_detail WHERE username = p_target AND is_admin = false;
      RETURN QUERY SELECT true, '已设置 ' || p_target || ' VIP等级: ' || p_detail;

    WHEN 'delete_video' THEN
      DELETE FROM public.videos WHERE video_id = p_target;
      RETURN QUERY SELECT true, '已删除视频 ' || p_target;

    ELSE
      RETURN QUERY SELECT false, '未知操作: ' || p_action;
  END CASE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.admin_action(TEXT, TEXT, TEXT, TEXT) TO anon;


-- RPC: 注册 (重新启用, 任何人可注册, 默认free)
DROP FUNCTION IF EXISTS public.register_account(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.register_account(p_username TEXT, p_password_hash TEXT, p_device_id TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT, vip_level TEXT, is_admin BOOLEAN) AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM public.user_accounts WHERE username = p_username) THEN
        RETURN QUERY SELECT false, '用户名已存在', ''::TEXT, false; RETURN;
    END IF;
    INSERT INTO public.user_accounts (username, password_hash, device_id, vip_level, is_admin)
    VALUES (p_username, p_password_hash, p_device_id, 'free', false);
    RETURN QUERY SELECT true, '注册成功', 'free'::TEXT, false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.register_account(TEXT, TEXT, TEXT) TO anon;
-- ═══════════════════════════════════════════
-- 好友 + 私信 + 系统配置 + 管理员功能
-- ═══════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.friends (
    user1 TEXT NOT NULL, user2 TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user1, user2)
);
ALTER TABLE public.friends ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理好友" ON public.friends;
CREATE POLICY "anon 管理好友" ON public.friends FOR ALL TO anon USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.messages (
    id SERIAL PRIMARY KEY,
    from_user TEXT NOT NULL, to_user TEXT NOT NULL,
    content TEXT NOT NULL, is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理私信" ON public.messages;
CREATE POLICY "anon 管理私信" ON public.messages FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE INDEX IF NOT EXISTS idx_msg_users ON public.messages(from_user, to_user);
CREATE INDEX IF NOT EXISTS idx_msg_time ON public.messages(created_at DESC);

CREATE TABLE IF NOT EXISTS public.system_config (
    key TEXT PRIMARY KEY, value TEXT DEFAULT '',
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.system_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon 管理配置" ON public.system_config;
CREATE POLICY "anon 管理配置" ON public.system_config FOR ALL TO anon USING (true) WITH CHECK (true);
INSERT INTO public.system_config (key, value) VALUES ('site_name', 'VideoDB') ON CONFLICT (key) DO NOTHING;
INSERT INTO public.system_config (key, value) VALUES ('announce_text', '') ON CONFLICT (key) DO NOTHING;

-- RPC: 添加好友
DROP FUNCTION IF EXISTS public.add_friend(TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.add_friend(p_from TEXT, p_to TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.friends WHERE user1=p_from AND user2=p_to) THEN
    RETURN QUERY SELECT false, '已发送过请求';
  ELSE
    INSERT INTO public.friends (user1, user2) VALUES (p_from, p_to);
    RETURN QUERY SELECT true, '好友请求已发送';
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.add_friend(TEXT, TEXT) TO anon;

-- RPC: 处理好友请求
DROP FUNCTION IF EXISTS public.handle_friend(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.handle_friend(p_user TEXT, p_from TEXT, p_action TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
BEGIN
  IF p_action = 'accept' THEN
    UPDATE public.friends SET status='accepted' WHERE user1=p_from AND user2=p_user;
    RETURN QUERY SELECT true, '已接受';
  ELSE
    DELETE FROM public.friends WHERE user1=p_from AND user2=p_user;
    RETURN QUERY SELECT true, '已拒绝';
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.handle_friend(TEXT, TEXT, TEXT) TO anon;

-- RPC: 好友列表
DROP FUNCTION IF EXISTS public.get_friends(TEXT);
CREATE OR REPLACE FUNCTION public.get_friends(p_user TEXT)
RETURNS TABLE(friend_username TEXT) AS $$
BEGIN
  RETURN QUERY SELECT f.user2 FROM public.friends f WHERE f.user1=p_user AND f.status='accepted'
  UNION SELECT f.user1 FROM public.friends f WHERE f.user2=p_user AND f.status='accepted';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.get_friends(TEXT) TO anon;

-- RPC: 好友请求列表
DROP FUNCTION IF EXISTS public.get_friend_requests(TEXT);
CREATE OR REPLACE FUNCTION public.get_friend_requests(p_user TEXT)
RETURNS TABLE(from_user TEXT) AS $$
BEGIN
  RETURN QUERY SELECT f.user1 FROM public.friends f WHERE f.user2=p_user AND f.status='pending';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.get_friend_requests(TEXT) TO anon;

-- RPC: 发私信
DROP FUNCTION IF EXISTS public.send_message(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.send_message(p_from TEXT, p_to TEXT, p_content TEXT)
RETURNS TABLE(success BOOLEAN) AS $$
BEGIN
  INSERT INTO public.messages (from_user, to_user, content) VALUES (p_from, p_to, p_content);
  RETURN QUERY SELECT true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.send_message(TEXT, TEXT, TEXT) TO anon;

-- RPC: 获取私信
DROP FUNCTION IF EXISTS public.get_messages(TEXT, TEXT, INTEGER);
CREATE OR REPLACE FUNCTION public.get_messages(p_user TEXT, p_with TEXT, p_limit INTEGER DEFAULT 50)
RETURNS TABLE(id INTEGER, from_user TEXT, to_user TEXT, content TEXT, is_read BOOLEAN, created_at TIMESTAMPTZ) AS $$
BEGIN
  UPDATE public.messages SET is_read=true WHERE to_user=p_user AND from_user=p_with AND NOT is_read;
  RETURN QUERY SELECT m.id,m.from_user,m.to_user,m.content,m.is_read,m.created_at
  FROM public.messages m WHERE (m.from_user=p_user AND m.to_user=p_with) OR (m.from_user=p_with AND m.to_user=p_user)
  ORDER BY m.created_at DESC LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.get_messages(TEXT, TEXT, INTEGER) TO anon;

-- RPC: 未读私信数
DROP FUNCTION IF EXISTS public.unread_count(TEXT);
CREATE OR REPLACE FUNCTION public.unread_count(p_user TEXT)
RETURNS TABLE(cnt BIGINT) AS $$
BEGIN RETURN QUERY SELECT COUNT(*)::BIGINT FROM public.messages WHERE to_user=p_user AND NOT is_read; END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.unread_count(TEXT) TO anon;

-- RPC: 查看用户收藏
DROP FUNCTION IF EXISTS public.view_user_favs(TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.view_user_favs(p_viewer TEXT, p_target TEXT)
RETURNS TABLE(video_id TEXT) AS $$
DECLARE is_friend BOOLEAN; is_admin_viewer BOOLEAN;
BEGIN
  SELECT (is_admin) INTO is_admin_viewer FROM public.user_accounts WHERE username=p_viewer;
  SELECT EXISTS(SELECT 1 FROM public.friends WHERE ((user1=p_viewer AND user2=p_target) OR (user1=p_target AND user2=p_viewer)) AND status='accepted') INTO is_friend;
  IF NOT is_admin_viewer AND NOT is_friend AND p_viewer != p_target THEN RETURN; END IF;
  RETURN QUERY SELECT cf.video_id FROM public.cloud_favorites cf WHERE cf.device_id IN (SELECT device_id FROM public.user_accounts WHERE username=p_target) ORDER BY cf.created_at DESC LIMIT 100;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.view_user_favs(TEXT, TEXT) TO anon;

-- RPC: 改密码
DROP FUNCTION IF EXISTS public.change_password(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.change_password(p_username TEXT, p_old_hash TEXT, p_new_hash TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
BEGIN
  UPDATE public.user_accounts SET password_hash=p_new_hash WHERE username=p_username AND password_hash=p_old_hash;
  IF FOUND THEN RETURN QUERY SELECT true, '密码修改成功';
  ELSE RETURN QUERY SELECT false, '原密码错误'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.change_password(TEXT, TEXT, TEXT) TO anon;

-- RPC: 管理员重置别人密码
DROP FUNCTION IF EXISTS public.admin_reset_password(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.admin_reset_password(p_admin TEXT, p_target TEXT, p_new_hash TEXT)
RETURNS TABLE(success BOOLEAN, message TEXT) AS $$
DECLARE v_admin RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username=p_admin AND is_admin=true AND banned=false;
  IF v_admin IS NULL THEN RETURN QUERY SELECT false, '无管理员权限'; RETURN; END IF;
  UPDATE public.user_accounts SET password_hash=p_new_hash WHERE username=p_target AND is_admin=false;
  IF FOUND THEN RETURN QUERY SELECT true, '已重置密码';
  ELSE RETURN QUERY SELECT false, '用户不存在'; END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.admin_reset_password(TEXT, TEXT, TEXT) TO anon;

-- RPC: 搜索用户
DROP FUNCTION IF EXISTS public.search_users(TEXT);
CREATE OR REPLACE FUNCTION public.search_users(p_query TEXT)
RETURNS TABLE(username TEXT, vip_level TEXT, verified BOOLEAN) AS $$
BEGIN
  RETURN QUERY SELECT a.username, a.vip_level, a.verified
  FROM public.user_accounts a WHERE a.username ILIKE '%'||p_query||'%' AND a.banned=false ORDER BY a.created_at DESC LIMIT 30;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.search_users(TEXT) TO anon;

-- RPC: 管理员获取全站配置
DROP FUNCTION IF EXISTS public.get_config(TEXT);
CREATE OR REPLACE FUNCTION public.get_config(p_key TEXT DEFAULT NULL)
RETURNS TABLE(key TEXT, value TEXT) AS $$
BEGIN
  IF p_key IS NULL THEN
    RETURN QUERY SELECT c.key, c.value FROM public.system_config c;
  ELSE
    RETURN QUERY SELECT c.key, c.value FROM public.system_config c WHERE c.key=p_key;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
GRANT EXECUTE ON FUNCTION public.get_config(TEXT) TO anon;

-- RPC: 管理员设置配置
DROP FUNCTION IF EXISTS public.set_config(TEXT, TEXT, TEXT);
CREATE OR REPLACE FUNCTION public.set_config(p_admin TEXT, p_key TEXT, p_value TEXT)
RETURNS TABLE(success BOOLEAN) AS $$
DECLARE v_admin RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username=p_admin AND is_admin=true;
  IF v_admin IS NULL THEN RETURN; END IF;
  INSERT INTO public.system_config (key, value, updated_at) VALUES (p_key, p_value, NOW())
  ON CONFLICT (key) DO UPDATE SET value=p_value, updated_at=NOW();
  RETURN QUERY SELECT true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.set_config(TEXT, TEXT, TEXT) TO anon;

-- RPC: 全站统计 (管理员)
DROP FUNCTION IF EXISTS public.site_stats(TEXT);
CREATE OR REPLACE FUNCTION public.site_stats(p_admin TEXT)
RETURNS TABLE(total_users BIGINT, total_videos BIGINT, total_messages BIGINT, playable_videos BIGINT) AS $$
DECLARE v_admin RECORD;
BEGIN
  SELECT * INTO v_admin FROM public.user_accounts WHERE username=p_admin AND is_admin=true;
  IF v_admin IS NULL THEN RETURN; END IF;
  SELECT COUNT(*) INTO total_users FROM public.user_accounts;
  SELECT COUNT(*) INTO total_videos FROM public.videos;
  SELECT COUNT(*) INTO total_messages FROM public.messages;
  SELECT COUNT(*) INTO playable_videos FROM public.videos WHERE has_mp4=true;
  RETURN NEXT;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
GRANT EXECUTE ON FUNCTION public.site_stats(TEXT) TO anon;
